/**
 * 
 */
package com.expression.evaluation;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;

import org.junit.Test;

import com.expression.evaluation.StringCalulator;

/**
 * @author rajekumar
 *
 */
public class StringCalculatorTest {
	
	@Test
	public void tesSum() throws IOException{
		StringCalulator myCalculator = new StringCalulator();
		
		
		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		int noOfTestCases = Integer.parseInt(in.readLine());
		while (noOfTestCases>0) {
			String s = in.readLine();
			// String s = "8*+7";
			// String s = "7+(6*5^2+3-4/2)";
			// String s = "(8*5/8)-(3/1)-5";
			// String s = "7+(67(56*2))";
			if (myCalculator.stringObservation(s)) {
				if (myCalculator.checkIfParenthesis(s)) {
					String postfix = myCalculator.parseInfix2Postfix(s);
					if (myCalculator.checkIfPostFixValidated(postfix)) {
						System.out.println(myCalculator.postfix2Evaluation(postfix));
						//assertEquals(result , result);
					} else {
						System.out.println("INVALID EXPRESSION");
					}
				} else {
					System.out.println("INVALID EXPRESSION");
				}
			} else {
				System.out.println("INVALID EXPRESSION");
			}
			noOfTestCases--;
		}
		
	}

}
