/**
 * 
 */
package com.expression.evaluation;

import java.util.Stack;

/**
 * @author rajekumar
 *
 */
public class StringCalulator {

	public boolean checkIfOperand(char c) {
		return ('0' <= c && c <= '9') || ('a' <= c && c <= 'z') || ('A' <= c && c <= 'Z');
	}

	public int getThePrecedence(char c) {
		if (c == '^')
			return 6;
		if (c == '*' || c == '/')
			return 5;
		if (c == '-' || c == '+')
			return 4;
		if (c == '>' || c == '<' || c == '=' || c == '#')
			return 3;
		if (c == '.')
			return 2;
		if (c == '|')
			return 1;
		return 0;
	}

	public boolean checkIfParenthesis(String s) {
		int stack = 0;
		for (int i = 0; i < s.length(); ++i) {
			char c = s.charAt(i);
			if (c == '(')
				++stack;
			else if (c == ')') {
				--stack;
				if (stack < 0)
					return false;
			}
		}
		return stack == 0;
	}

	public String parseInfix2Postfix(String s) {
		StringBuilder out = new StringBuilder("");
		Stack<Character> stack = new Stack<>();

		for (int i = 0; i < s.length(); ++i) {
			char c = s.charAt(i);

			if (checkIfOperand(c)) {
				out.append(c);
				continue;
			}

			if (c == '(') {
				stack.add(c);
				continue;
			}

			if (c == ')') {
				char ch = stack.pop();

				StringBuilder temp = new StringBuilder("");
				while (ch != '(') {
					temp.append(ch);
					ch = stack.pop();
				}

				if (temp.length() == 0) // empty parenthesis
					return ""; // will be invalidated by the postfix checker

				out.append(temp.toString());
				continue;
			}

			// here are only operators
			if (stack.empty()) {
				stack.push(c);
			}

			else {
				while (!stack.empty() && (getThePrecedence(stack.peek()) >= getThePrecedence(c)))
					out.append(stack.pop());
				stack.push(c);
			}
		}

		while (!stack.empty())
			out.append(stack.pop());

		return out.toString();
	}

	public boolean checkIfPostFixValidated(String s) {
		if (s.equals(""))
			return false;

		int stack = 0;
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (c == '(' || c == ')')
				continue;

			if (checkIfOperand(c)) {
				++stack;
			} else {
				stack -= 2;
				if (stack < 0)
					return false;
				++stack;
			}
		}
		return stack == 1;
	}

	public boolean stringObservation(String s) {
		for (int i = 0; i < s.length(); i++) {
			char c = s.charAt(i);
			if (checkIfOperand(c) == false && getThePrecedence(c) == 0 && c != '(' && c != ')')
				return false;
		}
		return true;
	}

	/*public static void main(String[] args) throws IOException {

		BufferedReader in = new BufferedReader(new InputStreamReader(System.in));
		// PrintStream out = new PrintStream(System.out);

		while (true) {
			String s = in.readLine();
			// String s = "8*+7";
			// String s = "7+(6*5^2+3-4/2)";
			// String s = "(8*5/8)-(3/1)-5";
			// String s = "7+(67(56*2))";
			if (stringObservation(s)) {
				if (checkIfParenthesis(s)) {
					String postfix = parseInfix2Postfix(s);
					if (checkIfPostFixValidated(postfix)) {
						System.out.println(
								postfix + " | evaluation for this expression is :" + postfix2Evaluation(postfix));
					} else {
						System.out.println("INVALID EXPRESSION");
					}
				} else {
					System.out.println("INVALID EXPRESSION");
				}
			} else {
				System.out.println("INVALID EXPRESSION");
			}
		}
	}*/

	public int postfix2Evaluation(String s) {
		Stack<Integer> stack = new Stack<Integer>();

		int x = 0, y = 0;
		char ch[] = s.toCharArray();

		for (char c : ch) {
			if (c >= '0' && c <= '9') {
				stack.push((int) (c - '0'));
			} else {
				y = stack.pop();
				x = stack.pop();
				switch (c) {
				case '+':
					stack.push(x + y);
					break;
				case '-':
					stack.push(x - y);
					break;
				case '*':
					stack.push(x * y);
					break;
				case '/':
					stack.push(x / y);
					break;
				case '^':
					stack.push((int) Math.pow(x, y));
					break;

				default:
					break;
				}
			}
		}
		return stack.pop();
	}

}
